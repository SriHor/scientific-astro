/* South Indian + North Indian chart HTML for rasi-phala. */
(function (global) {
  'use strict';

  var SI_ORDER = [
    'Meena', 'Mesha', 'Vrishabha', 'Mithuna',
    'Kumbha', null, null, 'Karka',
    'Makara', null, null, 'Simha',
    'Dhanu', 'Vrischika', 'Tula', 'Kanya'
  ];
  var ABBR = {
    Lagna: 'As', Surya: 'Su', Chandra: 'Mo', Kuja: 'Ma', Budha: 'Me', Guru: 'Ju',
    Shukra: 'Ve', Shani: 'Sa', Rahu: 'Ra', Ketu: 'Ke'
  };

  function fmtDeg(d) {
    var x = Number(d);
    if (!isFinite(x)) return '';
    var deg = Math.floor(x);
    var m = Math.round((x - deg) * 60);
    if (m === 60) { m = 0; deg++; }
    return deg + '°' + String(m).padStart(2, '0') + '′';
  }

  function byRashi(chart, includeLagna) {
    var map = {};
    var T = global.RasiTransit;
    T.RASHIS.forEach(function (r) { map[r] = []; });
    T.GRAHAS.forEach(function (g) {
      var p = chart.grahas[g];
      map[p.rashi].push({
        name: g, deg: p.deg, retro: p.retro, nak: p.nakshatra
      });
    });
    if (includeLagna && chart.lagna && chart.lagna.rashi && map[chart.lagna.rashi]) {
      map[chart.lagna.rashi].unshift({
        name: 'Lagna', deg: chart.lagna.deg, retro: false, nak: ''
      });
    }
    return map;
  }

  function houseOf(rashi, lagnaRashi) {
    var T = global.RasiTransit;
    var a = T.RASHIS.indexOf(rashi);
    var b = T.RASHIS.indexOf(lagnaRashi);
    return ((a - b + 12) % 12) + 1;
  }

  function planetLine(p, compact) {
    var lab = compact ? (ABBR[p.name] || p.name) : p.name;
    var r = p.retro ? (compact ? 'R' : ' (R)') : '';
    var d = compact ? '' : (' <span class="deg">' + fmtDeg(p.deg) + '</span>');
    return '<div class="si-p ni-p">' + lab + r + d + '</div>';
  }

  function south(chart, lagnaRashi, title, includeLagna) {
    var map = byRashi(chart, includeLagna);
    var html = '<table class="si-grid" cellspacing="2" cellpadding="0"><tbody>';
    var r, h, isL, pls, row, col;
    for (row = 0; row < 4; row++) {
      html += '<tr>';
      for (col = 0; col < 4; col++) {
        r = SI_ORDER[row * 4 + col];
        if (r === null) {
          html += '<td class="si-center"></td>';
          continue;
        }
        isL = r === lagnaRashi;
        h = houseOf(r, lagnaRashi);
        pls = (map[r] || []).map(function (p) { return planetLine(p, false); }).join('');
        html += '<td class="' + (isL ? 'lagna' : '') + '">' +
          '<div class="si-h">H' + h + (isL ? ' · Lagna' : '') + '</div>' +
          '<div class="si-r">' + r + '</div>' +
          pls + '</td>';
      }
      html += '</tr>';
    }
    html += '</tbody></table>';
    return '<div class="chart-card"><h4>' + title + ' · South Indian</h4><div class="si-wrap">' + html + '</div></div>';
  }

  function north(chart, lagnaRashi, title, includeLagna) {
    var T = global.RasiTransit;
    var map = byRashi(chart, includeLagna);
    var lagIdx = T.RASHIS.indexOf(lagnaRashi);
    var houses = '';
    var h, r, isL, pls;
    for (h = 1; h <= 12; h++) {
      r = T.RASHIS[(lagIdx + h - 1) % 12];
      isL = h === 1;
      pls = (map[r] || []).map(function (p) { return planetLine(p, true); }).join('');
      houses += '<div class="ni-h ni-h' + h + (isL ? ' lagna' : '') + '">' +
        '<div class="ni-num">H' + h + (isL ? ' L' : '') + '</div>' +
        '<div class="ni-r">' + r + '</div>' + pls + '</div>';
    }
    return '<div class="chart-card"><h4>' + title + ' · North Indian</h4>' +
      '<div class="ni-wrap"><div class="ni-box"><div class="ni-diamond"></div>' + houses + '</div></div></div>';
  }

  function render(chart, lagnaRashi, title, style, includeLagna) {
    title = title || 'Rasi Chart';
    return style === 'north'
      ? north(chart, lagnaRashi, title, includeLagna)
      : south(chart, lagnaRashi, title, includeLagna);
  }

  /* Parashari / JHora continuous D-9: floor(sid / 3°20′) mod 12. Same as getNavamsaRashi. */
  function navamsaIdx(sid) {
    var lon = ((Number(sid) % 360) + 360) % 360;
    return Math.floor(lon / (10 / 3)) % 12;
  }

  function navamsaDeg(sid) {
    var lon = ((Number(sid) % 360) + 360) % 360;
    return (lon % (10 / 3)) * 9;
  }

  function toNavamsaChart(chart) {
    var T = global.RasiTransit;
    var grahas = {};
    T.GRAHAS.forEach(function (g) {
      var p = chart.grahas[g];
      var idx = navamsaIdx(p.sid);
      grahas[g] = {
        name: g, en: p.en, sid: p.sid, rashi: T.RASHIS[idx], rashiEn: T.RASHI_EN[idx],
        rashiTe: T.RASHI_TE[idx], rashiIdx: idx, deg: navamsaDeg(p.sid),
        nakshatra: p.nakshatra, retro: p.retro
      };
    });
    var lIdx = navamsaIdx(chart.lagna.sid);
    return {
      grahas: grahas,
      lagna: {
        sid: chart.lagna.sid, rashi: T.RASHIS[lIdx], rashiEn: T.RASHI_EN[lIdx],
        rashiTe: T.RASHI_TE[lIdx], rashiIdx: lIdx, deg: navamsaDeg(chart.lagna.sid)
      }
    };
  }

  global.RasiCharts = {
    render: render,
    south: south,
    north: north,
    toNavamsaChart: toNavamsaChart,
    fmtDeg: fmtDeg,
    ABBR: ABBR
  };
})(window);
